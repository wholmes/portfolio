#!/bin/bash
echo "ℹ️  SQLite is already the default configuration!"
echo ""
echo "If you want to use MySQL instead, run:"
echo "   cp config-mysql.php config.php"
echo ""
echo "To start your server:"
echo "   php -S localhost:8000"
